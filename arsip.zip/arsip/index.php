<?php
	echo '<script>window.location.href = "login.php";</script>';
?>