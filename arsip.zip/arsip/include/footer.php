<footer>
  <div class="container">
    <div class="row">

      <div class="col-lg-6 col-md-6">
        <h3>Site Map</h3>
        <ul class="list-unstyled three-column">
          <li>Home</li>
          <li>Services</li>
          <li>About</li>
          <li>Code</li>
          <li>Design</li>
          <li>Host</li>
          <li>Contact</li>
          <li>Company</li>
        </ul>
        <ul class="list-unstyled socila-list">
          <li><i class="fa fa-facebook-square fa-2x"></i></li>
          <li><i class="fa fa-twitter-square fa-2x"></i></li>
          <li><i class="fa fa-instagram fa-2x"></i></li>
          <li><i class="fa fa-google fa-2x"></i></li>
          <li><i class="fa fa-pinterest fa-2x"></i></li>
          <li><i class="fa fa-linkedin fa-2x"></i></li>
          <li style="margin-top: 10px;">Contact : 0856-2344-4322</li>
        </ul>
      </div>

      <div class="col-lg-6 col-md-6">
        <h3>About</h3>
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Expedita sapiente sint, nulla, nihil
          repudiandae commodi voluptatibus corrupti animi sequi aliquid magnam debitis, maxime quam recusandae
          harum esse fugiat. Itaque, culpa?</p>
      </div>
    </div>
  </div>
  <div class="copyright text-center">
    Copyright &copy; 2020 <span>Arsip</span>
  </div>
</footer>
</body>
<script src="assets/js/core/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="assets/js/core/bootstrap.min.js" type="text/javascript"></script>
<script src="assets/js/core/bootstrap.min.js" type="text/javascript"></script>

</html>