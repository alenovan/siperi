<?php
session_start();
$_SESSION["menu"] = "user";
include './include/header.php';

$id  = $_GET['id'];
$sql = mysqli_query($con, "SELECT * FROM tb_user where id_user = $id");
$found  = mysqli_num_rows($sql);
if ($found == 0) {
    echo '<script>window.location.href = "./user.php";</script>';
}

if (isset($_GET["status"]) == "execute") {
    $passwordBaru        = $_POST["passwordBaru"];
    if ($passwordBaru != "") {
        if (strlen($passwordBaru) < 6) {
            echo '<script>window.location.href = "./ubahPasswordUser.php?error=passwordBaru&id=' . $id . '";</script>';
            die();
        }
    }
    $passwordKonfirmasi  = $_POST["passwordKonfirmasi"];
    if ($passwordKonfirmasi != "") {
        if ($passwordBaru != $passwordKonfirmasi) {
            echo '<script>window.location.href = "./ubahPasswordUser.php?error=passwordKonfirmasi&id=' . $id . '";</script>';
            die();
        }
    }

    $newPassEnk = md5($passwordBaru);
    $query = mysqli_query($con, "UPDATE tb_user SET password = '$newPassEnk' WHERE id_user = $id");
    echo '<script>window.location.href = "./ubahPasswordUser.php?error=none&id=' . $id . '";</script>';
}

$alertError = "";
$displayError = "none";
$type = "danger";
if (isset($_GET["error"])) {
    $error = $_GET["error"];

    if ($error == "passwordBaru") {
        $alertError = "Silahkan masukkan password minimal 6 karakter.";
        $displayError = "block";
    }

    if ($error == "passwordKonfirmasi") {
        $alertError = "Konfirmasi Password tidak sama dengan Password Baru";
        $displayError = "block";
    }
    if ($error == "none") {
        $alertError = "Ubah Password sukses";
        $displayError = "block";
        $type = "success";
    }
}
?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Ubah Password</h4>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-<?php echo $type; ?>" style="display: <?php echo $displayError; ?>">
                            <i class="fa fa-warning"></i> <?php echo $alertError; ?>
                        </div>
                        <form action="ubahPasswordUser.php?status=execute&id=<?php echo $id ?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Password Baru <font color="red">*</font></label>
                                        <input type="password" class="form-control" name="passwordBaru" placeholder="Password Baru" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Konfirmasi Password <font color="red">*</font></label>
                                        <input type="password" class="form-control" name="passwordKonfirmasi" placeholder="Konfirmasi Password" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <font color="red">*</font> = Required
                                </div>
                            </div>
                            <br>
                            <button type="submit" class="btn btn-info">Save</button> &nbsp; <a href="./user_edit.php?id=<?php echo $id ?>" class="btn btn-danger">Cancel</a>
                            <br><br>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include './include/footer.php' ?>