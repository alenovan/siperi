<?php
session_start();
$_SESSION["menu"] = "profil";
include './include/header.php';

$id  = $_SESSION['id_user'];
if (isset($_GET["status"]) == "execute") {
    $passwordLama        = $_POST["passwordLama"];
    if ($passwordLama != "") {
        $passEnk = md5($passwordLama);
        $check = mysqli_query($con, "SELECT password FROM tb_user WHERE id_user = $id");
        $row   = mysqli_fetch_array($check);
        if ($passEnk != $row["password"]) {
            echo '<script>window.location.href = "./ubahPassword.php?error=passwordLama";</script>';
            die();
        }
    }

    $passwordBaru        = $_POST["passwordBaru"];
    if ($passwordBaru != "") {
        if (strlen($passwordBaru) < 6) {
            echo '<script>window.location.href = "./ubahPassword.php?error=passwordBaru";</script>';
            die();
        }
    }
    $passwordKonfirmasi  = $_POST["passwordKonfirmasi"];
    if ($passwordKonfirmasi != "") {
        if ($passwordBaru != $passwordKonfirmasi) {
            echo '<script>window.location.href = "./ubahPassword.php?error=passwordKonfirmasi";</script>';
            die();
        }
    }

    $newPassEnk = md5($passwordBaru);
    $query = mysqli_query($con, "UPDATE tb_user SET password = '$newPassEnk' WHERE id_user = $id");
    echo '<script>window.location.href = "./ubahPassword.php?error=none";</script>';
}

$alertError = "";
$displayError = "none";
$type = "danger";
if (isset($_GET["error"])) {
    $error = $_GET["error"];
    if ($error == "passwordLama") {
        $alertError = "Password Lama yang Anda masukkan salah.";
        $displayError = "block";
    }

    if ($error == "passwordBaru") {
        $alertError = "Silahkan masukkan password minimal 6 karakter.";
        $displayError = "block";
    }

    if ($error == "passwordKonfirmasi") {
        $alertError = "Konfirmasi Password tidak sama dengan Password Baru";
        $displayError = "block";
    }
    if ($error == "none") {
        $alertError = "Ubah Password sukses";
        $displayError = "block";
        $type = "success";
    }
}
?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Ubah Password</h4>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-<?php echo $type; ?>" style="display: <?php echo $displayError; ?>">
                            <i class="fa fa-warning"></i> <?php echo $alertError; ?>
                        </div>
                        <form action="ubahPassword.php?status=execute" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Password Lama <font color="red">*</font></label>
                                        <input type="password" class="form-control" name="passwordLama" placeholder="Password Lama" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Password Baru <font color="red">*</font></label>
                                        <input type="password" class="form-control" name="passwordBaru" placeholder="Password Baru" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Konfirmasi Password <font color="red">*</font></label>
                                        <input type="password" class="form-control" name="passwordKonfirmasi" placeholder="Konfirmasi Password" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <font color="red">*</font> = Required
                                </div>
                            </div>
                            <br>
                            <button type="submit" class="btn btn-info">Save</button> &nbsp; <a href="./profil.php" class="btn btn-danger">Cancel</a>
                            <br><br>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include './include/footer.php' ?>