            <footer class="footer">
                <div class="container-fluid">
                    <nav>
                        <ul class="footer-menu">
                            <li>
                                <a href="#">
                                    <i class="fa fa-facebook-square"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="fa fa-twitter-square"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="fa fa-pinterest-square"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="fa fa-google-plus"></i>
                                </a>
                            </li>
                        </ul>
                        <p class="copyright text-center">
                            ©
                            <script>
                                document.write(new Date().getFullYear())
                            </script>
                            <a href="#">Arsip</a>, made with love for a better web
                        </p>
                    </nav>
                </div>
            </footer>
            </div>
            </div>
            </body>
            <script src="../assets/js/core/jquery.3.2.1.min.js" type="text/javascript"></script>
            <script src="../assets/js/core/popper.min.js" type="text/javascript"></script>
            <script src="../assets/js/core/bootstrap.min.js" type="text/javascript"></script>
            <script src="../assets/js/plugins/bootstrap-switch.js"></script>
            <script src="../assets/js/plugins/chartist.min.js"></script>
            <script src="../assets/js/plugins/bootstrap-notify.js"></script>
            <script src="../assets/js/ckeditor.js"></script>
            <script src="../assets/js/light-bootstrap-dashboard.js?v=2.0.0 " type="text/javascript"></script>
            <script src="../assets/js/demo.js"></script>
            <script src="../assets/evo-calendar/js/evo-calendar.js"></script>
            <script src="../assets/js/style.js"></script>
            <?php
            if ($_SESSION["menu"] == "dashboard") {
                echo "<script type='text/javascript'>";
                echo "$(document).ready(function() {";
                echo "$('#calendar').evoCalendar({";
                echo "calendarEvents: [";

                $query    = "SELECT tb_arsip_keluar.idArsip, tb_arsip_keluar.noArsip, tb_arsip_keluar.tglPenciptaan, tb_arsip_keluar.perihal
                FROM tb_arsip_keluar
                WHERE tb_arsip_keluar.isDeleted = 0";
                $sql      = mysqli_query($con, $query);
                while ($row = mysqli_fetch_array($sql)) {
                    echo "{";
                    echo "id:'" . $row["idArsip"] . "',";
                    echo "name:'" . $row["noArsip"] . "',";
                    echo "description:'" . $row["perihal"] . "',";
                    echo "date:'" . $row["tglPenciptaan"] . "',";
                    echo "type:'event'";
                    echo "},";
                }

                $query    = "SELECT tb_arsip_masuk.idArsip, tb_arsip_masuk.noArsip, tb_arsip_masuk.tglPenciptaan, tb_arsip_masuk.perihal
                FROM tb_arsip_masuk
                WHERE tb_arsip_masuk.isDeleted = 0";
                $sql      = mysqli_query($con, $query);
                while ($row = mysqli_fetch_array($sql)) {
                    echo "{";
                    echo "id:'" . $row["idArsip"] . "',";
                    echo "name:'" . $row["noArsip"] . "',";
                    echo "description:'" . $row["perihal"] . "',";
                    echo "date:'" . $row["tglPenciptaan"] . "',";
                    echo "type:'holiday'";
                    echo "},";
                }

                echo "]";
                echo "});";
                echo "});";
                echo "</script>";
            }
            ?>

            </html>