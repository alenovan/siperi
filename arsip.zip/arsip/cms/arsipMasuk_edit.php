<?php
session_start();
$_SESSION["menu"] = "arsipMasuk";
include './include/header.php';

$id     = $_GET["id"];
$sql    = mysqli_query($con, "SELECT * FROM tb_arsip_masuk WHERE idArsip=$id AND isDeleted = 0");
$found  = mysqli_num_rows($sql);
if ($found == 0) {
    echo '<script>window.location.href = "./arsipMasuk.php";</script>';
}
$rowFetch    = mysqli_fetch_array($sql);

if (isset($_GET["status"]) == "execute") {

    $noArsip            = $_POST["no_arsip"];
    $asal               = $_POST["asal"];
    $tglPencipta        = $_POST["tanggal"];
    $kepada             = $_POST["kepada"];
    $keteranganArsip    = $_POST["keteranganArsip"];
    $perihal            = $_POST["perihal"];
    $kode               = $_POST["kode"];
    $lokasi             = $_POST["lokasi"];
    $tanggalP           = $_POST["tanggalP"];
    $keteranganAsli     = $_POST["keteranganAsli"];
    $jumlah             = $_POST["jumlah"];
    $jenis              = $_POST["jenis"];
    $updated_by         = $_SESSION['id_user'];
    $date               = date("Y:m:d H:i:s");
    $banner             = $_FILES['fileUpload']['name'];
    if ($banner != "") {
        $bannerpath         = "../assets/file/upload/" . $banner;
        move_uploaded_file($_FILES["fileUpload"]["tmp_name"], $bannerpath);
        $query = mysqli_query($con, "UPDATE tb_arsip_masuk SET noArsip = '$noArsip', asalSurat = '$asal', tglPenciptaan = '$tglPencipta', kepada = '$kepada', 
                                keterangan = '$keteranganArsip', lampiran = '$banner', perihal = '$perihal', idKode = '$kode', idLokasi = '$lokasi', tglPenyimpanan = '$tanggalP', 
                                keteranganAsli = '$keteranganAsli', jumlah = '$jumlah', idJenis = '$jenis', updated_by=$updated_by, updated_date='$date' 
                                WHERE idArsip = $id");
    } else {
        $query = mysqli_query($con, "UPDATE tb_arsip_masuk SET noArsip = '$noArsip', asalSurat = '$asal', tglPenciptaan = '$tglPencipta', kepada = '$kepada', 
                                keterangan = '$keteranganArsip', perihal = '$perihal', idKode = '$kode', idLokasi = '$lokasi', tglPenyimpanan = '$tanggalP', 
                                keteranganAsli = '$keteranganAsli', jumlah = '$jumlah', idJenis = '$jenis', updated_by=$updated_by, updated_date='$date' 
                                WHERE idArsip = $id");
    }
    echo '<script>window.location.href = "./arsipMasuk.php";</script>';
}
?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Edit Arsip Masuk</h4>
                    </div>
                    <div class="card-body">
                        <form action="arsipMasuk_edit.php?status=execute&id=<?php echo $id; ?>" method="post" enctype="multipart/form-data">
                            <hr>
                            <h5><b>Form Identitas Arsip</b></h5>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>No. Arsip <font color="red">*</font></label>
                                        <input type="text" class="form-control" name="no_arsip" placeholder="No. Arsip" value="<?php echo $rowFetch["noArsip"] ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Asal Surat <font color="red">*</font></label>
                                        <input type="text" class="form-control" name="asal" placeholder="Asal Surat" value="<?php echo $rowFetch["asalSurat"] ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Tanggal Penciptaan <font color="red">*</font></label>
                                        <input type="date" class="form-control" name="tanggal" placeholder="Tanggal Penciptaan" value="<?php echo $rowFetch["tglPenciptaan"] ?>" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Kepada <font color="red">*</font></label>
                                        <input type="text" class="form-control" name="kepada" placeholder="Kepada" value="<?php echo $rowFetch["kepada"] ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Keterangan <font color="red">*</font></label>
                                        <select class="form-control" name="keteranganArsip" id="keteranganArsip" required>
                                            <option value="">---select---</option>
                                            <?php
                                            $result = mysqli_query($con, "SELECT * FROM tb_keterangan");
                                            while ($row = mysqli_fetch_array($result)) {
                                            ?>
                                                <option value="<?php echo $row["id_keterangan"] ?>" <?php if ($rowFetch["keterangan"] == $row["id_keterangan"]) {
                                                                                                        echo "selected";
                                                                                                    } ?>><?php echo $row["keterangan_name"] ?></option>
                                            <?php
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Lampiran <font color="red">*</font></label>
                                        <a target="_blank" href="../assets/file/upload/<?php echo $rowFetch["lampiran"] ?>">Lihat Lampiran</a>
                                        <input type="file" accept="image/*" class="form-control" name="fileUpload" id="fileUpload" value="">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Perihal <font color="red">*</font></label>
                                        <textarea class="form-control" name="perihal" id="perihal" required><?php echo $rowFetch["perihal"] ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <h5><b>Form Penyimpanan</b></h5>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Kode Klarifikasi</label>
                                        <select class="form-control" name="kode" id="kode">
                                            <option value="">---select---</option>
                                            <?php
                                            $result = mysqli_query($con, "SELECT * FROM tb_kode");
                                            while ($row = mysqli_fetch_array($result)) {
                                            ?>
                                                <option value="<?php echo $row["id_kode"] ?>" <?php if ($rowFetch["idKode"] == $row["id_kode"]) {
                                                                                                    echo "selected";
                                                                                                } ?>><?php echo $row["kode_name"] ?></option>
                                            <?php
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Lokasi Arsip</label>
                                        <select class="form-control" name="lokasi" id="lokasi">
                                            <option value="">---select---</option>
                                            <?php
                                            $result = mysqli_query($con, "SELECT * FROM tb_lokasi");
                                            while ($row = mysqli_fetch_array($result)) {
                                            ?>
                                                <option value="<?php echo $row["id_lokasi"] ?>" <?php if ($rowFetch["idLokasi"] == $row["id_lokasi"]) {
                                                                                                    echo "selected";
                                                                                                } ?>><?php echo $row["lokasi_name"] ?></option>
                                            <?php
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Tanggal Penyimpanan</label>
                                        <input type="date" class="form-control" name="tanggalP" placeholder="Tanggal Penyimpanan" value="<?php echo $rowFetch["tglPenyimpanan"] ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Keterangan Keaslian</label>
                                        <select class="form-control" name="keteranganAsli" id="keteranganAsli">
                                            <option value="">---select---</option>
                                            <?php
                                            $result = mysqli_query($con, "SELECT * FROM tb_keteranganAsli");
                                            while ($row = mysqli_fetch_array($result)) {
                                            ?>
                                                <option value="<?php echo $row["id_keteranganAsli"] ?>" <?php if ($rowFetch["keteranganAsli"] == $row["id_keteranganAsli"]) {
                                                                                                            echo "selected";
                                                                                                        } ?>><?php echo $row["keteranganAsli_name"] ?></option>
                                            <?php
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Jumlah</label>
                                        <input type="number" class="form-control" name="jumlah" placeholder="Jumlah" min="0" value="<?php echo $rowFetch["jumlah"] ?>">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Jenis Media</label>
                                        <select class="form-control" name="jenis" id="jenis">
                                            <option value="">---select---</option>
                                            <?php
                                            $result = mysqli_query($con, "SELECT * FROM tb_jenis_media");
                                            while ($row = mysqli_fetch_array($result)) {
                                            ?>
                                                <option value="<?php echo $row["id_jenis"] ?>" <?php if ($rowFetch["idJenis"] == $row["id_jenis"]) {
                                                                                                    echo "selected";
                                                                                                } ?>><?php echo $row["jenis_name"] ?></option>
                                            <?php
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <font color="red">*</font> = Required
                                </div>
                            </div>
                            <br>
                            <button type="submit" class="btn btn-info btn-sm">Save</button> &nbsp; <a href="./arsipMasuk.php" class="btn btn-danger btn-sm">Cancel</a>
                            <br><br>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include './include/footer.php' ?>