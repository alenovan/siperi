<?php
session_start();
$_SESSION["menu"] = "kode";
include './include/header.php';

if (isset($_GET["status"]) == "execute") {
    $nama  = $_POST["nama"];
    $query = mysqli_query($con, "INSERT INTO tb_kode VALUES ('', '$nama')");
    echo '<script>window.location.href = "./kode.php";</script>';
}
?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Add Kode Klarifikasi</h4>
                    </div>
                    <div class="card-body">
                        <form action="kode_add.php?status=execute" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Name <font color="red">*</font></label>
                                        <input type="text" class="form-control" name="nama" placeholder="Name" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <font color="red">*</font> = Required
                                </div>
                            </div>
                            <br>
                            <button type="submit" class="btn btn-info">Save</button> &nbsp; <a href="./unit.php" class="btn btn-danger">Cancel</a>
                            <br><br>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include './include/footer.php' ?>