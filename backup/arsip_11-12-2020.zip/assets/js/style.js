$(".alertFile").hide();
function goUpload() {
    var formData = new FormData($('#Myform')[0]);
    $.ajax({
        url: 'ajax/upload_image.php',
        data: formData,
        async: false,
        contentType: false,
        processData: false,
        cache: false,
        type: 'POST',
        success: function(data) {
            if (data.indexOf('Error') == -1) {
                $('.imgShow').empty();
                $('.imgShow').html("<img class='img-responsive' src='../assets/img/upload/" + data + "' style='width: 100%' alt='...'>");
                $('#imageInput').val(data);
            } else {
                $(".alertFile").show();
                $(".alertFile").html("<i class='fa fa-warning'></i> " + data);
            }
        },
    });
    return false;
}

function goUploadFile() {
    var formData = new FormData($('#Myform')[0]);
    $.ajax({
        url: 'ajax/upload_file.php',
        data: formData,
        async: false,
        contentType: false,
        processData: false,
        cache: false,
        type: 'POST',
        success: function(data) {
            if (data.indexOf('Error') == -1) {
                $('#fileInput').val(data);
            } else {
                $(".alertFile").show();
                $(".alertFile").html("<i class='fa fa-warning'></i> " + data);
            }
        },
    });
    return false;
}

function goSearch(page) {
    var key = $("#search").val();
    window.location = (page + ".php?key=" + key);
}

function goType() {
    var type = $("#typeSearch").val();
    if (type == 2){
        $("#fromDate").show();
        $("#toDate").show();
        $("#search").hide();
    }else{
        $("#fromDate").hide();
        $("#toDate").hide();
        $("#search").show();
    }
}

function goSearchArsip(page){
    var type = $("#typeSearch").val();
    if (type == 2){
        var from = $("#fromDate").val();
        var to   = $("#toDate").val();
        if (from == ""){
            alert("Masukkan Dari tanggal.");
            off();
        }

        if (to == ""){
            alert("Masukkan Ke tanggal.");
            off();
        }
        
        if (from > to){
            alert("Dari tanggal lebih besar dari Ke tanggal.");
            off();
        }
    }
    var url = $('#searchArsip').attr('action');
    $('#searchArsip').attr('action', url + "&page=" + page);
    $("#searchArsip").submit();
}