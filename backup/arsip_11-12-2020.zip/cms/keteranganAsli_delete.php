<?php
	require 'include/config.php';
	$id_unit = $_GET["id"];
	$query = mysqli_query($con, "DELETE FROM tb_unit_pengolah WHERE id_unit=$id_unit");
    echo '<script>window.location.href = "./unit.php";</script>';
?>v