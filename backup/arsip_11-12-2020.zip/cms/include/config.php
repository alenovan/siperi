<?php
$servername = "localhost";
$database = "db_arsip";
$username = "root";
$password = "";

$con = mysqli_connect($servername, $username, $password, $database);
if (!$con) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
