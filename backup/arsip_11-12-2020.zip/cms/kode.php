<?php
session_start();
$_SESSION["menu"] = "kode";
$key = "";
if (isset($_GET["key"]) != "") {
  $key = $_GET["key"];
}
?>
<?php include './include/header.php'; ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="card strpied-tabled-with-hover">
          <div class="card-body table-full-width table-responsive" style="padding: 20px;">
            <div class="col-md-12">
              <div class="row">
                <div class="col-md-9">
                  <font style="font-size:20px;">Kode Klarifikasi List</font> &nbsp;&nbsp;&nbsp; <a href="./kode_add.php" class="btn btn-success btn-sm" style="margin-top: -5px;">ADD</a>
                </div>
                <div class="col-md-3 text-right">
                  Search : <input type="text" name="search" id="search" onchange="goSearch('kode');" value="<?php echo $key ?>">
                </div>
              </div>
            </div>
            <table class="table table-hover table-striped">
              <thead>
                <th class="text-center">No</th>
                <th>Name</th>
                <th>Action</th>
              </thead>
              <tbody>
                <?php
                $sqlSearch = "";
                if ($key != "") {
                  $sqlSearch = " WHERE kode_name LIKE '%" . $key . "%'";
                }
                $per_page = 10;
                $page = isset($_GET["page"]) ? (int)$_GET["page"] : 1;
                $start = ($page > 1) ? ($page * $per_page) - $per_page : 0;
                $result = mysqli_query($con, "SELECT * FROM tb_kode" . $sqlSearch);
                $total = mysqli_num_rows($result);
                $pages = ceil($total / $per_page);
                $query = "SELECT * FROM tb_kode " . $sqlSearch . " LIMIT $start, $per_page";
                $no = $start + 1;
                $sql = mysqli_query($con, $query);
                if ($total > 0) {
                  while ($row = mysqli_fetch_array($sql)) {
                ?>
                    <tr>
                      <td class="text-center" style="width: 80px"><?php echo $no++; ?></td>
                      <td style="width: 1200px;"><?php echo $row["kode_name"] ?></td>
                      <td>
                        <a href="./kode_edit.php?id=<?php echo $row['id_kode'] ?>" class="btn btn-warning btn-sm">EDIT</a>&nbsp;
                        <a href="./kode_delete.php?id=<?php echo $row['id_kode'] ?>" class="btn btn-danger btn-sm" onclick="javascript:return confirm('Are you sure you want to delete this user?')">DELETE</a>
                      </td>
                    </tr>
                  <?php
                  }
                } else {
                  ?>
                  <tr>
                    <th colspan="3" class="text-center">Currently there is no record</td>
                  </tr>
                <?php
                }
                ?>
              </tbody>
            </table>
            <div class="col-md-12">
              <ul class="pagination pagination-sm">
                <?php for ($i = 1; $i <= $pages; $i++) { ?>
                  <li class="page-item <?php if ($page == $i) {
                                          echo 'active';
                                        } ?>"><a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
                <?php } ?>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include './include/footer.php' ?>