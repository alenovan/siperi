<?php
require 'include/config.php';
$id_jenis = $_GET["id"];
$query = mysqli_query($con, "DELETE FROM tb_jenis_media WHERE id_jenis=$id_jenis");
echo '<script>window.location.href = "./jenis.php";</script>';
?>v