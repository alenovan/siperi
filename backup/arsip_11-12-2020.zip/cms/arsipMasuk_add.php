<?php
session_start();
$_SESSION["menu"] = "arsipMasuk";
include './include/header.php';

if (isset($_GET["status"]) == "execute") {

    $noArsip            = $_POST["no_arsip"];
    $asal               = $_POST["asal"];
    $tglPencipta        = $_POST["tanggal"];
    $kepada             = $_POST["kepada"];
    $keteranganArsip    = $_POST["keteranganArsip"];
    $banner             = $_FILES['fileUpload']['name'];
    if ($banner != "") {
        $bannerpath         = "../assets/file/upload/" . $banner;
        move_uploaded_file($_FILES["fileUpload"]["tmp_name"], $bannerpath);
    }
    $perihal            = $_POST["perihal"];
    $kode               = $_POST["kode"];
    $lokasi             = $_POST["lokasi"];
    $tanggalP           = $_POST["tanggalP"];
    $keteranganAsli     = $_POST["keteranganAsli"];
    $jumlah             = $_POST["jumlah"];
    $jenis              = $_POST["jenis"];
    $created_by         = $_SESSION['id_user'];

    $query = mysqli_query($con, "INSERT INTO tb_arsip_masuk (noArsip, asalSurat, tglPenciptaan, kepada, keterangan, lampiran, perihal,
                                idKode, idLokasi, tglPenyimpanan, keteranganAsli, jumlah, idJenis, created_by) 
                                VALUES 
                                ('$noArsip', '$asal', '$tglPencipta', '$kepada', '$keteranganArsip', '$banner', '$perihal', '$kode', '$lokasi', '$tanggalP',
                                '$keteranganAsli', '$jumlah', '$jenis', $created_by)");
    echo '<script>window.location.href = "./arsipMasuk.php";</script>';
}
?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Add Arsip Masuk</h4>
                    </div>
                    <div class="card-body">
                        <form action="arsipMasuk_add.php?status=execute" method="post" enctype="multipart/form-data">
                            <hr>
                            <h5><b>Form Identitas Arsip</b></h5>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>No. Arsip <font color="red">*</font></label>
                                        <input type="text" class="form-control" name="no_arsip" placeholder="No. Arsip" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Asal Surat <font color="red">*</font></label>
                                        <input type="text" class="form-control" name="asal" placeholder="Asal Surat" value="" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Tanggal Penciptaan <font color="red">*</font></label>
                                        <input type="date" class="form-control" name="tanggal" placeholder="Tanggal Penciptaan" value="" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Kepada <font color="red">*</font></label>
                                        <input type="text" class="form-control" name="kepada" placeholder="Kepada" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Keterangan <font color="red">*</font></label>
                                        <select class="form-control" name="keteranganArsip" id="keteranganArsip" required>
                                            <option value="">---select---</option>
                                            <?php
                                            $result = mysqli_query($con, "SELECT * FROM tb_keterangan");
                                            while ($row = mysqli_fetch_array($result)) {
                                            ?>
                                                <option value="<?php echo $row["id_keterangan"] ?>"><?php echo $row["keterangan_name"] ?></option>
                                            <?php
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Lampiran <font color="red">*</font></label>
                                        <input type="file" accept="image/*" class="form-control" name="fileUpload" id="fileUpload" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Perihal <font color="red">*</font></label>
                                        <textarea class="form-control" name="perihal" id="perihal" required></textarea>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <h5><b>Form Penyimpanan</b></h5>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Kode Klarifikasi</label>
                                        <select class="form-control" name="kode" id="kode">
                                            <option value="">---select---</option>
                                            <?php
                                            $result = mysqli_query($con, "SELECT * FROM tb_kode");
                                            while ($row = mysqli_fetch_array($result)) {
                                            ?>
                                                <option value="<?php echo $row["id_kode"] ?>"><?php echo $row["kode_name"] ?></option>
                                            <?php
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Lokasi Arsip</label>
                                        <select class="form-control" name="lokasi" id="lokasi">
                                            <option value="">---select---</option>
                                            <?php
                                            $result = mysqli_query($con, "SELECT * FROM tb_lokasi");
                                            while ($row = mysqli_fetch_array($result)) {
                                            ?>
                                                <option value="<?php echo $row["id_lokasi"] ?>"><?php echo $row["lokasi_name"] ?></option>
                                            <?php
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Tanggal Penyimpanan</label>
                                        <input type="date" class="form-control" name="tanggalP" placeholder="Tanggal Penyimpanan" value="">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Keterangan Keaslian</label>
                                        <select class="form-control" name="keteranganAsli" id="keteranganAsli">
                                            <option value="">---select---</option>
                                            <?php
                                            $result = mysqli_query($con, "SELECT * FROM tb_keteranganAsli");
                                            while ($row = mysqli_fetch_array($result)) {
                                            ?>
                                                <option value="<?php echo $row["id_keteranganAsli"] ?>"><?php echo $row["keteranganAsli_name"] ?></option>
                                            <?php
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Jumlah</label>
                                        <input type="number" class="form-control" name="jumlah" placeholder="Jumlah" min="0" value="">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Jenis Media</label>
                                        <select class="form-control" name="jenis" id="jenis">
                                            <option value="">---select---</option>
                                            <?php
                                            $result = mysqli_query($con, "SELECT * FROM tb_jenis_media");
                                            while ($row = mysqli_fetch_array($result)) {
                                            ?>
                                                <option value="<?php echo $row["id_jenis"] ?>"><?php echo $row["jenis_name"] ?></option>
                                            <?php
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <font color="red">*</font> = Required
                                </div>
                            </div>
                            <br>
                            <button type="submit" class="btn btn-info btn-sm">Save</button> &nbsp; <a href="./arsipMasuk.php" class="btn btn-danger btn-sm">Cancel</a>
                            <br><br>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include './include/footer.php' ?>