<?php
require 'include/config.php';
$id_kode = $_GET["id"];
$query = mysqli_query($con, "DELETE FROM tb_kode WHERE id_kode=$id_kode");
echo '<script>window.location.href = "./kode.php";</script>';
?>v