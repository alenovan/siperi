<?php
require_once 'cms/include/config.php';
if (isset($_GET["status"]) == "execute") {
	$username = $_POST["username"];
	$password = md5($_POST["password"]);

	$query = mysqli_query($con, "SELECT * FROM tb_user where username = '$username'  and password = '$password'");
	$found = mysqli_num_rows($query);
	if ($found > 0) {
		$row = mysqli_fetch_array($query);
		session_start();
		$_SESSION['nama'] = $row["name"];
		$_SESSION['id_user'] = $row["id_user"];
		$_SESSION['role'] = $row["role"];
		$_SESSION['username'] = $row["username"];
		echo '<script>window.location.href = "cms/dashboard.php";</script>';
	}
}

if (isset($_SESSION['id_user']) != "") {
	echo '<script>window.location.href = "cms/dashboard.php";</script>';
}
?>
<!DOCTYPE html>
<html>

<head>
	<title>LOGIN - CMS</title>
	<link href="./assets/css/bootstrap.min.css" rel="stylesheet" />
	<link href="./assets/css/style_login.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
</head>

<body>
	<div class="main">
		<div class="container">
			<center>
				<h1 style="color: white">LOGIN CMS ARSIP</h1>
				<br><br>
				<div class="middle">
					<div id="login">
						<form action="login.php?status=execute" method="post">
							<fieldset class="clearfix">
								<p><span class="fa fa-user"></span><input type="text" name="username" Placeholder="Username" required></p>
								<p><span class="fa fa-lock"></span><input type="password" name="password" Placeholder="Password" required></p>
								<div>
									<span style="width:48%; text-align:left;  display: inline-block;"><a class="small-text" href="#">Forgot
											password?</a></span>
									<span style="width:50%; text-align:right;  display: inline-block;"><input type="submit" value="Sign In"></span>
								</div>
							</fieldset>
							<div class="clearfix"></div>
						</form>
						<div class="clearfix"></div>
					</div>
					<div class="logo">
						<img src="./assets/img/logo.png" style="width: 50%;">
						<div class="clearfix"></div>
					</div>

				</div>
			</center>
		</div>
	</div>
</body>
<script src="./assets/js/core/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="./assets/js/core/bootstrap.min.js" type="text/javascript"></script>

</html>