<?php
session_start();
require 'include/config.php';
$id         = $_GET["id"];
$created_by = $_SESSION['id_user'];
$date       = date("Y:m:d H:i:s");

$query = mysqli_query($con, "UPDATE tb_arsip_masuk set isDeleted = 1, deleted_date = '$date', deleted_by = $created_by WHERE idArsip=$id");
echo '<script>window.location.href = "./arsipMasuk.php";</script>';
?>v