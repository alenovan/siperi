<?php
require 'include/config.php';
$id = $_GET["id"];
$query = mysqli_query($con, "DELETE FROM tb_keterangan WHERE id_keterangan=$id");
echo '<script>window.location.href = "./keterangan.php";</script>';
?>v