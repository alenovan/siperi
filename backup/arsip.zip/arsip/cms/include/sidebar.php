<div class="sidebar" data-image="../assets/img/sidebar-5.jpg">
    <div class="sidebar-wrapper">
        <div class="logo">
            <a href="" class="simple-text">
                ARSIP
            </a>
        </div>
        <ul class="nav">
            <li class="nav-item <?php if ($_SESSION["menu"] == "dashboard") {
                                    echo 'active';
                                } ?>">
                <a class="nav-link" href="./dashboard.php">
                    <i class="nc-icon nc-chart-pie-35"></i>
                    <p>Dashboard</p>
                </a>
            </li>
            <li class="nav-item <?php if ($_SESSION["menu"] == "profil") {
                                    echo 'active';
                                } ?>">
                <a class="nav-link" href="./profil.php">
                    <i class="nc-icon nc-badge"></i>
                    <p>Profil</p>
                </a>
            </li>
            <?php
            if ($_SESSION["role"] == 1) {
            ?>
                <li class="nav-item <?php if ($_SESSION["menu"] == "user") {
                                        echo 'active';
                                    } ?>">
                    <a class="nav-link" href="./user.php">
                        <i class="nc-icon nc-circle-09"></i>
                        <p>Management User</p>
                    </a>
                </li>
            <?php } ?>
            <li class="nav-item <?php if ($_SESSION["menu"] == "arsip") {
                                    echo 'active';
                                } ?>">
                <a href="#submenuarsip" data-toggle="collapse" aria-expanded="false" class="nav-link">
                    <div class="d-flex w-100 justify-content-start align-items-center">
                        <i class="nc-icon nc-email-85"></i>
                        <p>ARSIP</p>
                    </div>
                </a>
                <div id='submenuarsip' class="collapse sidebar-submenu <?php if ($_SESSION["menu"] == "arsipMasuk" || $_SESSION["menu"] == "arsipKeluar") {
                                                                            echo 'show';
                                                                        } ?>">
                    <a href="arsipKeluar.php" class="nav-link submenuside <?php if ($_SESSION["menu"] == "arsipKeluar") {
                                                                                echo 'active';
                                                                            } ?>">
                        <i class="nc-icon nc-stre-right"></i> <span class="menu-collapsed">Arsip Keluar</span>
                    </a>
                    <a href="arsipMasuk.php" class="nav-link submenuside <?php if ($_SESSION["menu"] == "arsipMasuk") {
                                                                                echo 'active';
                                                                            } ?>">
                        <i class="nc-icon nc-stre-right"></i> <span class="menu-collapsed">Arsip Masuk</span>
                    </a>
                </div>
            </li>
            <?php
            if ($_SESSION["role"] == 1) {
            ?>
                <li class="nav-item">
                    <a href="#submenumaster" data-toggle="collapse" aria-expanded="false" class="nav-link">
                        <div class="d-flex w-100 justify-content-start align-items-center">
                            <i class="nc-icon nc-badge"></i>
                            <p>DATA MASTER</p>
                        </div>
                    </a>
                    <div id='submenumaster' class="collapse sidebar-submenu <?php if ($_SESSION["menu"] == "keterangan" || $_SESSION["menu"] == "keteranganAsli" || $_SESSION["menu"] == "kode" || $_SESSION["menu"] == "lokasi" || $_SESSION["menu"] == "jenis") {
                                                                                echo 'show';
                                                                            } ?>">
                        <a href="keterangan.php" class="nav-link submenuside <?php if ($_SESSION["menu"] == "keterangan") {
                                                                                    echo 'active';
                                                                                } ?>">
                            <i class="nc-icon nc-stre-right"></i> <span class="menu-collapsed">Keterangan</span>
                        </a>
                        <a href="keteranganAsli.php" class="nav-link submenuside <?php if ($_SESSION["menu"] == "keteranganAsli") {
                                                                                        echo 'active';
                                                                                    } ?>">
                            <i class="nc-icon nc-stre-right"></i> <span class="menu-collapsed">Keterangan Asli</span>
                        </a>
                        <a href="kode.php" class="nav-link submenuside <?php if ($_SESSION["menu"] == "kode") {
                                                                            echo 'active';
                                                                        } ?>">
                            <i class="nc-icon nc-stre-right"></i> <span class="menu-collapsed">Kode Klarifikasi</span>
                        </a>
                        <a href="lokasi.php" class="nav-link submenuside <?php if ($_SESSION["menu"] == "lokasi") {
                                                                                echo 'active';
                                                                            } ?>">
                            <i class="nc-icon nc-stre-right"></i> <span class="menu-collapsed">Lokasi Arsip</span>
                        </a>
                        <a href="jenis.php" class="nav-link submenuside <?php if ($_SESSION["menu"] == "jenis") {
                                                                            echo 'active';
                                                                        } ?>">
                            <i class="nc-icon nc-stre-right"></i> <span class="menu-collapsed">Jenis Media</span>
                        </a>
                    </div>
                </li>
            <?php } ?>
        </ul>
    </div>
</div>