<?php
	require 'include/config.php';
	$id_lokasi = $_GET["id"];
	$query = mysqli_query($con, "DELETE FROM tb_lokasi WHERE id_lokasi=$id_lokasi");
    echo '<script>window.location.href = "./lokasi.php";</script>';
?>v