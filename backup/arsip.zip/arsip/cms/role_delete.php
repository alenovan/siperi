<?php
	require 'include/config.php';
	$id_role = $_GET["id"];
	$query = mysqli_query($con, "DELETE FROM tb_role WHERE id_role=$id_role");
    echo '<script>window.location.href = "./role.php";</script>';
?>v