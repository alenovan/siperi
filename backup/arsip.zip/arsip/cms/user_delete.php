<?php
	require 'include/config.php';
	$id_user = $_GET["id"];
	$query = mysqli_query($con, "DELETE FROM tb_user WHERE id_user=$id_user");
    echo '<script>window.location.href = "./user.php";</script>';
